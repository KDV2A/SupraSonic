import Cocoa

// Launch the application
let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
